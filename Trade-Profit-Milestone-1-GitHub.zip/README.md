# Trade Profit Milestone 1
Upload these files to the root of your GitHub repository. Vercel will deploy automatically.
