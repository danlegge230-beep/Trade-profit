# Trade Profit

A UK pricing calculator, job tracker and margin coach for tradespeople — pricing simulator, job history, coaching tips, trade presets, and a Free/Pro toggle for previewing paid features.

This is a single self-contained static site (`index.html`). There's no build step, no framework and no server required.

## Deploy to Vercel

**Option A — drag and drop (fastest)**
1. Go to https://vercel.com/new
2. Drag the whole project folder (or just `index.html`) onto the page
3. Vercel deploys it immediately as a static site — no configuration needed

**Option B — Vercel CLI**
```
npm i -g vercel
cd trade-profit-vercel
vercel
```
Follow the prompts (link or create a project, accept the defaults). Run `vercel --prod` when you're ready to go live.

**Option C — Git**
1. Push this folder to a GitHub/GitLab/Bitbucket repo
2. In Vercel, "Add New… → Project" → import that repo
3. Framework preset: "Other" (or leave as detected — Vercel auto-serves a bare `index.html` as a static site)
4. Deploy — no build command or output directory needed

Any of these gives you a live URL (e.g. `your-project.vercel.app`). Add a custom domain from the Vercel project's Domains tab whenever you're ready.

## What's different from the Claude artifact preview

Two features were limited by the Claude preview sandbox and are now fully working here:

- **Quote PDF export** — the quote preview now has a real "Download as PDF" button (uses the browser's native print-to-PDF).
- **Job export CSV** — the export screen now has a real "Download CSV" button that saves an actual `.csv` file, ready to open in Excel/Numbers/Sheets or import into accounting software.

Everything else (calculator, simulator, job history, coaching, trade presets, Trade Score, branding, settings) behaves exactly as it did in the artifact.

## The Free/Pro toggle is a demo, not real billing

The Plan switch in Settings just flips a flag in the browser's local storage — it's there so you (or anyone testing the site) can preview what Free vs Pro looks like. It is **not** connected to any payment processor, so as it stands anyone could switch themselves to Pro for free.

To sell Pro subscriptions for real, you'd need to add:
1. A payment provider (Stripe Checkout is the common choice for this kind of app)
2. A small backend or serverless function (a few Vercel serverless functions would do it — no need for a separate server) that creates checkout sessions and verifies subscription status
3. A database (or Stripe's own subscription status) as the source of truth for who is Pro — not the browser's local storage

The separate Next.js codebase (delivered earlier) is the starting point for that — it has the folder structure for a real backend and database. This static site is the fastest way to get the full app live and usable today; the Next.js version is the path to real accounts and billing later.

## Adding more built-in trades or presets later

Every trade's presets and coaching content live in one place near the top of the `<script>` block in `index.html`: the `TRADES` object. Each entry looks like:

```js
plasterer: {
  label: 'Plasterer',
  pluralLabel: 'Plasterers',
  presets: [ /* 7 example jobs */ ],
  materials: { plantLabel, consumablesLabel, plantMarkup, consumablesMarkup },
  highYield: { text, tag },
  overheadNote: '...',
  rateBenchmark: { low, high }
}
```

To add a new trade pack: copy an existing entry, fill in its fields, add its key to `TRADE_ORDER`, and redeploy (push to Git, or re-run `vercel --prod`). There's no admin UI for this yet — it's a text edit and a redeploy, which takes a couple of minutes on Vercel.

Users can also add their own custom job presets from inside the app (Settings → their trade's presets) — that already works with no code changes, and is separate from the built-in trade packs above.

## Local preview before deploying

Any static file server works, e.g.:
```
npx serve .
```
then open the printed local URL in your browser.
